#include <stdio.h>
int main() {
    printf("%s\n", "Hello world!");
    return 0;
}